# Ownership and dependencies

Source is assigned once; combine all three project/ trees for the existing application.

| Owner | Responsibilities |
|---|---|
| SecureVault-User | Active user components, password helpers, vault/account-security services, user tests, additive user migrations |
| SecureVault-Admin | Admin screen/features, Admin business controllers/service, Admin tests |
| SecureVault-Team-Integration | Shared auth/MFA/session/API clients, route hosts, common/security/telemetry, global styles/assets, manifests and infrastructure |

## Cross-package references found in source

| Importing source | Required source | Required package |
|---|---|---|
| `backend/src/main/java/com/securevault/admin/AdminController.java` | `backend/src/main/java/com/securevault/common/BcryptPasswordLength.java` | SecureVault-Team-Integration |
| `backend/src/main/java/com/securevault/admin/AdminController.java` | `backend/src/main/java/com/securevault/common/ClientIpResolver.java` | SecureVault-Team-Integration |
| `backend/src/main/java/com/securevault/admin/AdminService.java` | `backend/src/main/java/com/securevault/threat/DeviceMetadata.java` | SecureVault-Team-Integration |
| `backend/src/main/java/com/securevault/admin/AdminService.java` | `backend/src/main/java/com/securevault/threat/ThreatTelemetry.java` | SecureVault-Team-Integration |
| `backend/src/main/java/com/securevault/vault/AccountSecurityService.java` | `backend/src/main/java/com/securevault/auth/MfaCryptoService.java` | SecureVault-Team-Integration |
| `backend/src/main/java/com/securevault/vault/AccountSecurityService.java` | `backend/src/main/java/com/securevault/common/AccountPrincipal.java` | SecureVault-Team-Integration |
| `backend/src/main/java/com/securevault/vault/NotificationController.java` | `backend/src/main/java/com/securevault/common/AccountAuthenticationInterceptor.java` | SecureVault-Team-Integration |
| `backend/src/main/java/com/securevault/vault/ShareExpiryService.java` | `backend/src/main/java/com/securevault/threat/ThreatTelemetry.java` | SecureVault-Team-Integration |
| `backend/src/main/java/com/securevault/vault/SharingService.java` | `backend/src/main/java/com/securevault/common/AccountPrincipal.java` | SecureVault-Team-Integration |
| `backend/src/main/java/com/securevault/vault/SharingService.java` | `backend/src/main/java/com/securevault/threat/ThreatTelemetry.java` | SecureVault-Team-Integration |
| `backend/src/main/java/com/securevault/vault/VaultEvents.java` | `backend/src/main/java/com/securevault/common/AccountPrincipal.java` | SecureVault-Team-Integration |
| `backend/src/main/java/com/securevault/vault/VaultEvents.java` | `backend/src/main/java/com/securevault/threat/ThreatTelemetry.java` | SecureVault-Team-Integration |
| `backend/src/main/java/com/securevault/vault/VaultService.java` | `backend/src/main/java/com/securevault/common/AccountPrincipal.java` | SecureVault-Team-Integration |
| `backend/src/main/java/com/securevault/vault/VaultService.java` | `backend/src/main/java/com/securevault/threat/ThreatTelemetry.java` | SecureVault-Team-Integration |
| `backend/src/test/java/com/securevault/AdminThreatAuthorizationTest.java` | `backend/src/main/java/com/securevault/common/SecurityEventRecorder.java` | SecureVault-Team-Integration |
| `backend/src/test/java/com/securevault/vault/VaultPostgresIT.java` | `backend/src/main/java/com/securevault/admin/AdminSharingController.java` | SecureVault-Admin |
| `backend/src/test/java/com/securevault/vault/VaultPostgresIT.java` | `backend/src/main/java/com/securevault/auth/AccountIdentityController.java` | SecureVault-Team-Integration |
| `backend/src/test/java/com/securevault/vault/VaultPostgresIT.java` | `backend/src/main/java/com/securevault/auth/MfaCryptoService.java` | SecureVault-Team-Integration |
| `frontend/src/App.jsx` | `frontend/src/components/UserDashboard.jsx` | SecureVault-User |
| `frontend/src/components/AccountSecurityPanel.jsx` | `frontend/src/services/api.js` | SecureVault-Team-Integration |
| `frontend/src/components/AccountSecurityPanel.jsx` | `frontend/src/services/vaultApi.js` | SecureVault-Team-Integration |
| `frontend/src/components/AccountSecurityPanel.jsx` | `src/MfaSettingsPanel.jsx` | SecureVault-Team-Integration |
| `frontend/src/components/NotificationsPanel.jsx` | `frontend/src/services/vaultApi.js` | SecureVault-Team-Integration |
| `frontend/src/components/SecureShare.jsx` | `frontend/src/services/vaultApi.js` | SecureVault-Team-Integration |
| `frontend/src/components/VaultOverview.jsx` | `frontend/src/services/vaultApi.js` | SecureVault-Team-Integration |
| `frontend/src/components/VaultPanel.jsx` | `frontend/src/services/vaultApi.js` | SecureVault-Team-Integration |
| `src/AccountSecurity.test.jsx` | `frontend/src/services/vaultApi.js` | SecureVault-Team-Integration |
| `src/App.css` | `src/securevault-theme.css` | SecureVault-Team-Integration |
| `src/App.jsx` | `src/MfaSettingsPanel.jsx` | SecureVault-Team-Integration |
| `src/App.jsx` | `src/adminApi.js` | SecureVault-Team-Integration |
| `src/App.jsx` | `src/workspaceBridge.js` | SecureVault-Team-Integration |
| `src/Notifications.test.jsx` | `frontend/src/services/vaultApi.js` | SecureVault-Team-Integration |
| `src/SecureShare.test.jsx` | `frontend/src/services/vaultApi.js` | SecureVault-Team-Integration |
| `src/SharingMonitor.jsx` | `src/adminApi.js` | SecureVault-Team-Integration |
| `src/SharingMonitor.test.jsx` | `src/adminApi.js` | SecureVault-Team-Integration |
| `src/ThreatContext.jsx` | `src/adminApi.js` | SecureVault-Team-Integration |
| `src/ThreatContext.test.jsx` | `src/adminApi.js` | SecureVault-Team-Integration |
| `src/UserOverview.test.jsx` | `frontend/src/services/vaultApi.js` | SecureVault-Team-Integration |
| `src/UserVault.test.jsx` | `frontend/src/services/vaultApi.js` | SecureVault-Team-Integration |

Java wildcard imports and Spring injection also require the combined packages. This is static source dependency verification, not a successful build. npm/Maven external dependencies are specified by the Integration manifests. The AdminSecurityConfiguration/authentication infrastructure is shared, despite its existing Java admin package path. Threat detector implementation is Integration-owned; the Admin feature consumes it.
