# SecureVault modular handoff

Snapshot: eebed62ad678cb186bbed3d03838bbb62dc87966 on feature/security-monitoring, packaged 2026-11-04 (Asia/Calcutta).
This includes the current working-tree source, including local changes; it is not a commit-only export.
These are MODULAR HANDOFF PACKAGES, NOT independently runnable applications. No standalone module build has been verified.

## Integration steps
1. Review all three packages and their manifests. Coordinate edits by the ownership map in DEPENDENCIES.md.
2. Extract all three ZIPs into ONE NEW empty review folder. Each archive has a distinct module directory. Overlay the contents of each module's project/ directory into one combined project root, preserving relative paths. Do not flatten frontend/ or src/.
3. All original source paths have exactly one owner across the three archives. Shared source lives only in Team Integration. Integrate reviewed changes into your existing checkout manually; do not overwrite local credentials or data.
4. Use the supplied root and frontend package-lock.json files separately. The Admin app uses React 19; the user app uses React 18. Preserve Vite react/react-dom dedupe for shared MFA components; do not combine runtime installations or replace authentication with frontend role selection.
5. On a separate development machine, install requirements per manifests (Node compatible with Vite 8, npm, Java 17, Maven; Docker Desktop/Compose and PostgreSQL 16 for integration). Only in the combined review tree, npm ci at root and in frontend/ installs dependencies. No dependencies were installed during packaging.
6. Configure secrets independently through an approved local process. No .env file or template, local Compose override, credentials, production data or backups are supplied. Keep stable keys for any existing database; do not rotate JWT/MFA/vault keys as part of this handoff. SMTP must be explicitly configured and tested before email MFA is relied upon.
7. Root npm test runs the combined frontend tests. npm run build builds Admin; npm run build --prefix frontend builds User. cd backend then mvn test runs backend unit tests. Database integration tests and browser E2E require their documented disposable fixtures; review scripts before executing. Do not target an existing database with test fixtures.
8. Frontends expect ports 3000 (user) and 3001 (admin iframe/bridge); both proxy /api. Set VITE_API_TARGET=http://127.0.0.1:8085 in each development-server environment if retaining the existing laptop's backend port. Source defaults are 8080 for API and 5432 for PostgreSQL; the excluded local override used 8085/5433. Review loopback bindings and CORS together before changing ports. No services were started for packaging.

## Database safeguards
SQL files are implementation references, NOT approval to apply them. schema.sql contains initialization/destructive trigger operations and must NOT be rerun against an existing database. Review each additive migration against the target schema, take and restore-verify a protected backup, and obtain activation approval before applying. bootstrap scripts apply restricted audit privileges; preserve insert-only audit/history restrictions. Do not register duplicate accounts, alter roles, reset MFA or replace encryption keys as an integration shortcut.

## Verification and known limitations
Packaging verifies byte-for-byte source checksums, ZIP CRC/content, forbidden-file exclusions, cross-package relative import resolution and matching against local secret material. Synthetic values in source tests are disposable fixtures, not exported account credentials.
No application tests, service deployment, login, database migrations or independent-module execution were performed for THIS packaging task. Prior chat reported 67 frontend tests and both builds passing, plus isolated fixture browser checks; these are historical results, not a fresh certification of this snapshot. Existing user confirmation of workspace switching is also historical. Live expiry/revocation, full sharing flow between real accounts, SMTP and target-machine setup must be reverified safely.
The old root README describes demo-only vault functionality and is stale; it is intentionally not used as the handoff implementation inventory. Legacy frontend/src/components/VaultDashboard.jsx (unreferenced in the active App flow, contains demo rows), unused src/reportWebVitals.js, operational activation reports/scripts, private documents and local artifacts are excluded.
Geolocation requires a configured provider; unavailable location must remain unavailable. Device recognition is inferred from stored request metadata, not proof of identity or credential sharing. Password breach monitoring needs supplied assessment/provider data; do not interpret missing assessment as confirmed safety.

## Contents and integrity
project/ preserves original relative source paths. MANIFEST.json lists source SHA-256, byte counts and original paths. DEPENDENCIES.md maps cross-package source dependencies and shared ownership. No application code is rewritten in the archives. ZIP-SHA256.json beside the ZIPs records archive hashes.

## User module: purpose and implemented source
Includes the active User Workspace navigation/dashboard, My Vault encrypted credential CRUD frontend/backend, generator/strength assessment, categories/favorites, masked reveal/copy, centered Add/Edit modal, Secure Share/expiry/revocation, notifications, account security/sessions/devices, profile/help UI, focused frontend/backend tests and fixture browser scripts. Includes the three additive vault/notifications/account-security SQL migrations as references.
Requires Team Integration's authentication/MFA/session/API clients, identity controller, global styles, build/test manifests, common principals/authentication, telemetry and base schema. Shared telemetry is not copied here. Admin module is required when assembling the complete existing application because the integration router imports the Admin host and the backend contains shared security configuration.
Unverified here: new-machine build/runtime, live credential/share flows, clipboard permissions, target database migration state, email MFA, and all database fixture tests. Read script safety requirements; no automatic live activation.
