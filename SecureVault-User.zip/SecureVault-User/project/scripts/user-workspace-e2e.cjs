/* Real browser -> Vite -> Spring Boot -> disposable PostgreSQL regression.
 * Requires the labeled, verified disposable fixture used by VaultPostgresIT and its built test container.
 * Never targets the existing SecureVault database or services. No secret values are logged.
 */
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const {execFileSync,spawn}=require('node:child_process');
const crypto=require('node:crypto'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),db='securevault-user-phase1-db',built='securevault-user-phase1-tests',app='securevault-user-e2e-backend';
const api='http://127.0.0.1:18090',origin='http://127.0.0.1:13000';let stage='fixture safety checks';
const docker=(args,input)=>execFileSync('docker',args,{input,encoding:'utf8',stdio:['pipe','pipe','pipe'],windowsHide:true});
const sql=text=>docker(['exec','-i',db,'psql','-X','-U','postgres','-d','securevault_test','-v','ON_ERROR_STOP=1','-At'],text);
const delay=ms=>new Promise(r=>setTimeout(r,ms));
async function free(port){await new Promise((resolve,reject)=>{let s=net.createServer();s.once('error',reject);s.listen(port,'127.0.0.1',()=>s.close(resolve));});}
async function ready(url){for(let i=0;i<100;i++){try{if((await fetch(url)).ok)return;}catch{}await delay(300);}throw Error('Fixture service did not become ready');}
function base32(b){let bits=0,value=0,result='';for(const x of b){value=(value<<8)|x;bits+=8;while(bits>=5){result+='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'[(value>>>(bits-5))&31];bits-=5;}}return result;}
function totp(seed){const step=Buffer.alloc(8);step.writeBigUInt64BE(BigInt(Math.floor(Date.now()/30000)));const h=crypto.createHmac('sha1',seed).update(step).digest(),o=h[19]&15;return String((h.readUInt32BE(o)&0x7fffffff)%1000000).padStart(6,'0');}
(async()=>{
 assert.equal(docker(['inspect','--format','{{index .Config.Labels "securevault.purpose"}}',db]).trim(),'user-phase1-fixture');
 assert.equal(sql("SELECT shobj_description(oid,'pg_database') FROM pg_database WHERE datname=current_database();").trim(),'securevault-isolated-verification');
 await free(18090);await free(13000);
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'securevault-e2e-')),jar=path.join(dir,'backend.jar'),configFile=path.join(dir,'vite.config.mjs');
 let browser,server,created=false;
 try{
  stage='copy verified test artifact';docker(['cp',`${built}:/tmp/backend/target/securevault-backend-0.0.1-SNAPSHOT.jar`,jar]);
  const jwt=crypto.randomBytes(48),mfa=crypto.randomBytes(48),vault=crypto.randomBytes(48);
  const accounts=[false,false,true].map((admin,i)=>{const seed=crypto.randomBytes(20),id=crypto.randomUUID();return {id,admin,seed,username:`e2e-${i}-${crypto.randomBytes(6).toString('hex')}`,password:'Fixture-'+crypto.randomBytes(20).toString('hex')};});
  stage='seed isolated MFA accounts';sql('CREATE EXTENSION IF NOT EXISTS pgcrypto;');for(const a of accounts){const key=crypto.createHmac('sha256',mfa).update('SecureVault/TOTP encryption/v1').digest(),iv=crypto.randomBytes(12),cipher=crypto.createCipheriv('aes-256-gcm',key,iv);
   const value=Buffer.concat([cipher.update(base32(a.seed),'utf8'),cipher.final(),cipher.getAuthTag()]);const encrypted=`enc:v1:${iv.toString('base64url')}:${value.toString('base64url')}`;
   sql(`INSERT INTO users(id,username,email,password_hash,vault_key_salt,mfa_enabled,mfa_secret) VALUES ('${a.id}','${a.username}','${a.username}@example.invalid',crypt('${a.password}',gen_salt('bf',10)),'fixture-only',TRUE,'${encrypted}'); INSERT INTO user_roles(user_id,role_id) SELECT '${a.id}',id FROM roles WHERE role_name='ROLE_USER'${a.admin?" OR role_name='ROLE_ADMIN'":''};`);
  }
  // Apply the same narrow runtime grants to the disposable fixture, never broad grants on audit history.
  stage='fixture runtime grants';sql(fs.readFileSync(path.join(root,'database/bootstrap-app-privileges.sql'),'utf8').replaceAll('securevault_db','securevault_test').replace(/^REVOKE ALL ON securevault_bootstrap_state.*$/m,''));
  sql('ALTER ROLE securevault_app LOGIN;');
  const ip=docker(['inspect','--format','{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}',db]).trim();assert(/^172\.\d+\.\d+\.\d+$/.test(ip));
  const env={...process.env,JWT_SECRET_BASE64:jwt.toString('base64'),MFA_ENCRYPTION_KEY_BASE64:mfa.toString('base64'),VAULT_ENCRYPTION_KEY_BASE64:vault.toString('base64')};
  stage='isolated backend startup';
  execFileSync('docker',['run','-d','--name',app,'--label','securevault.purpose=user-phase1-fixture','-p','127.0.0.1:18090:8080','--mount',`type=bind,source=${jar},target=/fixture/backend.jar,readonly`,'-e','SERVER_ADDRESS=0.0.0.0','-e',`SPRING_DATASOURCE_URL=jdbc:postgresql://${ip}:5432/securevault_test`,'-e','SPRING_DATASOURCE_USERNAME=securevault_app','-e','JWT_SECRET_BASE64','-e','MFA_ENCRYPTION_KEY_BASE64','-e','VAULT_ENCRYPTION_KEY_BASE64','maven:3.9.9-eclipse-temurin-17','java','-jar','/fixture/backend.jar'],{env,stdio:'pipe',windowsHide:true});created=true;
  await ready(api+'/api/health');
  fs.writeFileSync(configFile,"import config from '"+require('node:url').pathToFileURL(path.join(root,'frontend/vite.config.js')).href+"'; const previous=config.server.proxy['/api'].configure; config.server.proxy['/api'].configure=proxy=>{previous?.(proxy);proxy.on('proxyReq',(req,incoming)=>req.setHeader('Origin',incoming.url.startsWith('/api/admin')?'http://127.0.0.1:3001':'http://127.0.0.1:3000'));}; export default config;");
  server=spawn(process.execPath,[path.join(root,'frontend/node_modules/vite/bin/vite.js'),'--config',configFile,'--host','127.0.0.1','--port','13000','--strictPort'],{cwd:path.join(root,'frontend'),env:{...process.env,VITE_API_TARGET:api},stdio:'ignore',windowsHide:true});await ready(origin);
  browser=await chromium.launch({channel:process.env.PLAYWRIGHT_CHANNEL||'msedge',headless:true});let errors=0;
  async function login(a){const c=await browser.newContext();
   // A temporary test frontend uses port 13000; present the existing allowed frontend origin to Spring's proxy-facing CORS check. No API responses are mocked.
   // The temporary Vite proxy supplies the existing allowed frontend origin. API responses are real.
   const p=await c.newPage();p.setDefaultTimeout(10000);p.on('pageerror',()=>errors++);stage='login form';await p.goto(origin);await p.getByLabel('Username or Email').fill(a.username);await p.getByLabel('Account Password',{exact:true}).fill(a.password);stage='password submission';const response=p.waitForResponse(r=>new URL(r.url()).pathname==='/api/login');await p.getByRole('button',{name:'Unlock Vault'}).click();const loginResponse=await response;stage='authenticator challenge (HTTP '+loginResponse.status()+')';await p.getByLabel('Six-digit verification code').fill(totp(a.seed));await p.getByRole('button',{name:'Verify and continue'}).click();stage='authenticated dashboard';await p.getByText('Stored credentials',{exact:true}).waitFor();return p;
  }
  stage='genuine password and authenticator login';const owner=await login(accounts[0]);
  stage='browser encrypted credential creation';await owner.getByRole('button',{name:'My Vault',exact:true}).click();await owner.getByRole('button',{name:'New Credential'}).click();
  const secret='Fixture-vault-'+crypto.randomBytes(16).toString('hex');await owner.getByLabel('Website / app name',{exact:true}).fill('E2E private item');await owner.getByLabel('Username / email',{exact:true}).fill('fixture-vault-user');await owner.getByLabel('Password',{exact:true}).fill(secret);await owner.getByRole('button',{name:'Save credential',exact:true}).click();await owner.getByRole('heading',{name:'E2E private item'}).waitFor();
  async function call(p,url,method='GET',body){return p.evaluate(async({url,method,body})=>{const r=await fetch('/api'+url,{method,headers:{Authorization:'Bearer '+sessionStorage.getItem('securevault_jwt'),...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})});return {status:r.status,data:r.status===204?null:await r.json()};},{url,method,body});}
  const list=await call(owner,'/account/vault/credentials');assert.equal(list.status,200);const item=list.data.find(i=>i.title==='E2E private item');assert(item);assert.equal(item.password,null);
  const stored=sql(`SELECT encrypted_data FROM credentials WHERE id='${item.id}';`);assert(!stored.includes(secret));assert(!stored.includes('E2E private item'));
  stage='two-user sharing, denial, notifications and revocation';const recipient=await login(accounts[1]);
  assert.equal((await call(recipient,'/account/vault/credentials/'+item.id)).status,404);
  const share=await call(owner,'/account/shares','POST',{credentialId:item.id,recipientId:accounts[1].id,expiresAt:new Date(Date.now()+600000).toISOString()});assert.equal(share.status,200);
  const received=await call(recipient,'/account/shares/'+share.data.id+'/credential');assert.equal(received.status,200);assert.equal(received.data.password,secret);
  assert.equal((await call(recipient,'/account/vault/credentials/'+item.id,'DELETE')).status,404);
  assert.equal((await call(recipient,'/admin/sharing')).status,403);
  const notices=await call(recipient,'/account/notifications');assert.equal(notices.status,200);assert(notices.data.items.some(n=>n.type==='CREDENTIAL_SHARED'));assert(!JSON.stringify(notices.data).includes(secret));
  stage='admin metadata privacy';
  // Authenticate the synthetic admin directly against the isolated backend. Never open the existing port-3001 app during this fixture test.
  const device=crypto.randomUUID(),headers={'Content-Type':'application/json','X-SecureVault-Device':device,'User-Agent':'SecureVault isolated fixture'};
  const challengeResponse=await fetch(api+'/api/login',{method:'POST',headers,body:JSON.stringify({identifier:accounts[2].username,password:accounts[2].password})});assert.equal(challengeResponse.status,202);
  const challenge=await challengeResponse.json();const verifiedResponse=await fetch(api+'/api/login/mfa',{method:'POST',headers,body:JSON.stringify({challengeId:challenge.challengeId,code:totp(accounts[2].seed)})});assert.equal(verifiedResponse.status,200);
  const verified=await verifiedResponse.json();const monitoredResponse=await fetch(api+'/api/admin/sharing',{headers:{Authorization:'Bearer '+verified.accessToken}});const monitored={status:monitoredResponse.status,data:await monitoredResponse.json()};
  assert.equal(monitored.status,200);assert(monitored.data.items.some(s=>s.id===share.data.id));assert(!JSON.stringify(monitored.data).includes(secret));assert(!JSON.stringify(monitored.data).includes('E2E private item'));
  await call(owner,'/account/shares/'+share.data.id,'DELETE');assert.equal((await call(recipient,'/account/shares/'+share.data.id+'/credential')).status,404);
  stage='credential update, deletion and dashboard totals';assert.equal((await call(owner,'/account/vault/credentials/'+item.id,'PUT',{title:'Updated fixture',url:'',username:'fixture',password:secret,categoryId:item.categoryId,notes:'',favorite:true})).status,200);
  assert.equal((await call(owner,'/account/vault/credentials/'+item.id,'DELETE')).status,204);assert.equal((await call(owner,'/account/vault/overview')).data.health.total,0);
  assert.equal(errors,0);console.log('PASS: full-stack browser login + TOTP, encrypted CRUD, two-user sharing, ownership/ROLE_USER denial, revocation, notifications, admin privacy and real totals.');
 }finally{
  if(browser)await browser.close();if(server)server.kill();
  if(created&&docker(['inspect','--format','{{index .Config.Labels "securevault.purpose"}}',app]).trim()==='user-phase1-fixture')docker(['rm','-f',app]);
  fs.rmSync(jar,{force:true});fs.rmSync(configFile,{force:true});fs.rmdirSync(dir);
 }
})().catch(()=>{console.error('FAIL: isolated full-stack regression at '+stage+'; secret-bearing details suppressed.');process.exitCode=1;});
